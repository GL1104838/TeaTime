package com.teatime.teatime;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ColorFilter;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.annotation.ColorRes;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v4.content.ContextCompat;
import android.support.v4.graphics.drawable.DrawableCompat;
import android.support.v7.app.ActionBar;
import android.view.View;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.Locale;

public class MainActivity extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {

    private NavigationView navigationView;
    private DrawerLayout drawerLayout;

    @Override
    protected void onRestart() {
        super.onRestart();
        //TODO : FIND a smarter way to only refresh when settings changed
        recreate();

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        drawerLayout = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawerLayout, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close){
            @Override
            public void onDrawerClosed(View drawerView) {
                // Called when a drawer has settled in a completely closed state.
                NavigationView nav = (NavigationView)drawerView;
                Menu m = nav.getMenu();
                //TODO : Refresh Tea List based on criterias
                updateSideMenuState(m);
                super.onDrawerClosed(drawerView);
            }
        };
        drawerLayout.addDrawerListener(toggle);

        toggle.syncState();
        ActionBar actionBar = getSupportActionBar();
        Drawable normalDrawable = ContextCompat.getDrawable(this,R.drawable.ic_menu_black_24dp);
        Drawable wrapDrawable = DrawableCompat.wrap(normalDrawable);
        DrawableCompat.setTint(wrapDrawable, this.getResources().getColor(android.R.color.holo_green_dark,null));
        actionBar.setHomeAsUpIndicator(wrapDrawable);
        actionBar.setDisplayShowTitleEnabled(false);
        actionBar.setDisplayHomeAsUpEnabled(true);
        navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);
        View headerView = navigationView.getHeaderView(0);
        TextView txtusername = (TextView)headerView.findViewById(R.id.txtUsername);
        txtusername.setText(PreferenceManager.getDefaultSharedPreferences(getApplicationContext()).getString("username_text",null));
    }



    @Override
    public void onBackPressed() {
        if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
            drawerLayout.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_actionbar, menu);

        MenuItem searchItem = menu.findItem(R.id.search_actionbar) ;
        MenuItem settingItem = menu.findItem(R.id.setting_actionbar);
            if(searchItem != null) {
            tintMenuIcon(searchItem,android.R.color.holo_green_dark);
        }
        if(settingItem != null){
            tintMenuIcon(settingItem,android.R.color.holo_green_dark);
        }
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();
        Menu m = navigationView.getMenu();
        if (id == R.id.setting_actionbar) {
            //Settings onClick
            //TODO : Go to Settings Activity
            Intent intent = new Intent(this, SettingsActivity.class);
            startActivity(intent);
            return true;
        }
        else if (id == R.id.search_actionbar) {
            //Search onClick
            //TODO : Go to Search Activity/Start Search Widget
            return true;
        }
        else
            return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        Menu m = navigationView.getMenu();
        int id = item.getItemId();
        //boolean mustCloseDrawer = false;
        if (id == R.id.nav_all){
            m.findItem(R.id.nav_type_blanc).setChecked(false);
            m.findItem(R.id.nav_type_bleu).setChecked(false);
            m.findItem(R.id.nav_type_rouge).setChecked(false);
            m.findItem(R.id.nav_type_vert).setChecked(false);
            m.findItem(R.id.nav_type_sombre).setChecked(false);
            m.findItem(R.id.nav_prop_flame).setChecked(false);
            m.findItem(R.id.nav_prop_caffeine).setChecked(false);
            m.findItem(R.id.nav_good_sucre).setChecked(false);
            m.findItem(R.id.nav_good_lait).setChecked(false);
            m.findItem(R.id.nav_good_autre).setChecked(false);
            updateSideMenuState(m);
        }
        else if(id == R.id.nav_type_the){
            boolean newState = !m.findItem(R.id.nav_type_blanc).isVisible();
            m.findItem(R.id.nav_type_blanc).setVisible(newState);
            m.findItem(R.id.nav_type_bleu).setVisible(newState);
            m.findItem(R.id.nav_type_rouge).setVisible(newState);
            m.findItem(R.id.nav_type_vert).setVisible(newState);
            m.findItem(R.id.nav_type_sombre).setVisible(newState);
        }
        else if(id == R.id.nav_prop_the) {
            boolean newState = !m.findItem(R.id.nav_prop_flame).isVisible();
            m.findItem(R.id.nav_prop_flame).setVisible(newState);
            m.findItem(R.id.nav_prop_caffeine).setVisible(newState);
        }
        else if(id == R.id.nav_bon_avec) {
            boolean newState = !m.findItem(R.id.nav_good_sucre).isVisible();
            m.findItem(R.id.nav_good_sucre).setVisible(newState);
            m.findItem(R.id.nav_good_lait).setVisible(newState);
            m.findItem(R.id.nav_good_autre).setVisible(newState);
        }
        else {
            if(item.isChecked()){
                item.setChecked(false);
            }
            else {
                item.setChecked(true);
            }
            //mustCloseDrawer = true;
            updateSideMenuState(m);
        }
        return false;
    }

    private void tintMenuIcon(MenuItem item, @ColorRes int color) {
        Drawable normalDrawable = item.getIcon();
        Drawable wrapDrawable = DrawableCompat.wrap(normalDrawable);
        DrawableCompat.setTint(wrapDrawable, this.getResources().getColor(color,null));

        item.setIcon(wrapDrawable);
    }

    private void updateSideMenuState(Menu m) {
        if (m.findItem(R.id.nav_type_vert).isChecked() ||
            m.findItem(R.id.nav_type_bleu).isChecked() ||
            m.findItem(R.id.nav_type_rouge).isChecked() ||
            m.findItem(R.id.nav_type_blanc).isChecked() ||
            m.findItem(R.id.nav_type_sombre).isChecked()){
            m.findItem(R.id.nav_type_blanc).setVisible(true);
            m.findItem(R.id.nav_type_bleu).setVisible(true);
            m.findItem(R.id.nav_type_rouge).setVisible(true);
            m.findItem(R.id.nav_type_vert).setVisible(true);
            m.findItem(R.id.nav_type_sombre).setVisible(true);
        }
        else{
            m.findItem(R.id.nav_type_blanc).setVisible(false);
            m.findItem(R.id.nav_type_bleu).setVisible(false);
            m.findItem(R.id.nav_type_rouge).setVisible(false);
            m.findItem(R.id.nav_type_vert).setVisible(false);
            m.findItem(R.id.nav_type_sombre).setVisible(false);
        }
        if( m.findItem(R.id.nav_prop_caffeine).isChecked() ||
            m.findItem(R.id.nav_prop_flame).isChecked()) {
            m.findItem(R.id.nav_prop_flame).setVisible(true);
            m.findItem(R.id.nav_prop_caffeine).setVisible(true);
        }
        else {
            m.findItem(R.id.nav_prop_flame).setVisible(false);
            m.findItem(R.id.nav_prop_caffeine).setVisible(false);
        }
        if( m.findItem(R.id.nav_good_sucre).isChecked() ||
            m.findItem(R.id.nav_good_lait).isChecked() ||
            m.findItem(R.id.nav_good_autre).isChecked()) {
            m.findItem(R.id.nav_good_sucre).setVisible(true);
            m.findItem(R.id.nav_good_lait).setVisible(true);
            m.findItem(R.id.nav_good_autre).setVisible(true);
        }
        else {
            m.findItem(R.id.nav_good_sucre).setVisible(false);
            m.findItem(R.id.nav_good_lait).setVisible(false);
            m.findItem(R.id.nav_good_autre).setVisible(false);
        }
    }

    @Override
    protected void attachBaseContext(Context newBase) {

        SharedPreferences pref =  PreferenceManager.getDefaultSharedPreferences(newBase);

        String lang = pref.getBoolean("enable_fr", false) ? "fr" : "en";

        Locale locale = new Locale(lang);

        Context context = LanguageContextWrapper.wrap(newBase, locale);
        super.attachBaseContext(context);
    }

    public void teaTextClick(View v) {
        //BUTTON STUB
        TextView textView = findViewById(R.id.textView1);
        LinearLayout linearLayout = findViewById(R.id.teaLayout1_2);
        if(textView.getVisibility() == View.GONE){
            textView.setVisibility(View.VISIBLE);
            linearLayout.setVisibility(View.VISIBLE);
        }
        else{
            textView.setVisibility(View.GONE);
            linearLayout.setVisibility(View.GONE);
        }
    }
}
